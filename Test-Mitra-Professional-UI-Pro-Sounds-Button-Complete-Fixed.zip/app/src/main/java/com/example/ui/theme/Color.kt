package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding - TEST MITRA Navy Blue & Emerald Green Theme (ZIP 1)
val MitraNavyPrimary = Color(0xFF1E3A8A)      // Deep Navy Blue (Brand Primary)
val MitraNavyDark = Color(0xFF0F172A)         // Dark Slate Navy
val MitraNavyLight = Color(0xFF3B82F6)        // Royal Blue
val MitraGreen = Color(0xFF059669)            // Vibrant Emerald Green (Active/Success)
val MitraGreenLight = Color(0xFFDCFCE7)       // Light Green Background
val MitraOrange = Color(0xFFD97706)           // Amber / Timer Warning
val MitraOrangeLight = Color(0xFFFEF3C7)      // Light Amber
val MitraError = Color(0xFFDC2626)            // Crimson Red / Delete / Danger
val MitraErrorLight = Color(0xFFFEE2E2)       // Light Red
val MitraBlueLight = Color(0xFFEFF6FF)        // Soft Ice Blue
val MitraBgLight = Color(0xFFF8FAFC)          // Clean Off-White Background
val MitraCardBg = Color(0xFFFFFFFF)           // Pure White
val MitraBorder = Color(0xFFE2E8F0)           // Subtle Border Grey
val MitraTextPrimary = Color(0xFF0F172A)      // Charcoal Heading Text
val MitraTextSecondary = Color(0xFF475569)    // Slate Body Text
val MitraTextMuted = Color(0xFF94A3B8)        // Light Grey Muted Text

// Color Palette from TEST MITRA RESULTS (ZIP 2)
val Slate50 = Color(0xFFF8FAFC)
val Slate100 = Color(0xFFF1F5F9)
val Slate200 = Color(0xFFE2E8F0)
val Slate300 = Color(0xFFCBD5E1)
val Slate400 = Color(0xFF94A3B8)
val Slate500 = Color(0xFF64748B)
val Slate600 = Color(0xFF475569)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)
val Slate950 = Color(0xFF020617)

val Indigo50 = Color(0xFFEEF2FF)
val Indigo100 = Color(0xFFE0E7FF)
val Indigo200 = Color(0xFFC7D2FE)
val Indigo300 = Color(0xFFA5B4FC)
val Indigo400 = Color(0xFF818CF8)
val Indigo500 = Color(0xFF6366F1)
val Indigo600 = Color(0xFF4F46E5)
val Indigo700 = Color(0xFF4338CA)
val Indigo900 = Color(0xFF312E81)
val Indigo950 = Color(0xFF1E1B4B)

val Cyan400 = Color(0xFF22D3EE)
val Cyan500 = Color(0xFF06B6D4)
val Cyan600 = Color(0xFF0891B2)

val Emerald400 = Color(0xFF34D399)
val Emerald500 = Color(0xFF10B981)
val Emerald600 = Color(0xFF059669)
val Emerald700 = Color(0xFF047857)

val Amber400 = Color(0xFFFBBF24)
val Amber500 = Color(0xFFF59E0B)
val Amber600 = Color(0xFFD97706)
val Amber700 = Color(0xFFB45309)

val Rose400 = Color(0xFFF87171)
val Rose500 = Color(0xFFEF4444)
val Rose600 = Color(0xFFE11D48)
val Rose700 = Color(0xFFBE123C)
